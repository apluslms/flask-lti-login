# flask-lti-login

LTI login application for Flask. This module makes it easy to use learning management system (LMS) with LTI 1.0 interface to authenticate users to external services.

